import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axios from "axios";
//import React from "react";

const initialState = {
    isAuthenticated : false,
    Cart:[]
}
const selectProduct = {
    user:'1',
    product:'1',
    product_qty:'1',
}
const token =  'dc698c58de090c5503185674062de95340fef996';

export  const fetchuserById = createAsyncThunk(
    'PostData',
    async()=>{ 
        try{  
          console.log('before axios post request')
    const productdata = await axios.post('http://127.0.0.1:8000/cart/',
//console.log('productDetails:',selectProduct),
    selectProduct,
    
      {
        headers: 
       {
        'Authorization' : `Token ${token}`,
        'Content-Type': 'application/json',
        'Accept' : 'application/json'
       },
     }
    )
    console.log('after axios post request' , productdata)
    return productdata.data;

    }catch(error){
        console.error('error' , error)
    }
}
)
export const cartSlice = createSlice({
    name:'Cart',
    initialState,
    reducers:{
        
        addtoCart:(state,action)=>{
            //debugger;
            state.isAuthenticated = true;
            const newItem = action.payload;
            state.Cart.push(newItem)
        },
        removeFromCart: (state, action) => {
            const itemId = action.payload;
            state.Cart = state.Cart.filter((item) => item.id !== itemId);
          },
          
    },
    extraReducers : (builder)=>{
        builder.addCase(fetchuserById.fulfilled,(state,action)=>{
          state.data=action.payload;
        })
    }
})
export const {addtoCart, removeFromCart} = cartSlice.actions
export default cartSlice.reducer;