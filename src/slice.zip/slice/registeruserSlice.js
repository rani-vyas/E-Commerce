import { createAsyncThunk, createSlice } from "@reduxjs/toolkit"
import axios from "axios"

const initialState= {
    //isAuthenticated: false,
    data:[{}]
}
const userDetails ={
    username:'user123',
    email:'user123@example.com',
    password1:'user98765',
    password2:'user98765'
}
//const token = localStorage.getItem('dc698c58de090c5503185674062de95340fef996');
export const  fetchUsers = createAsyncThunk(
    'registerdUser',
    async()=>{
        const User = await axios.post('http://127.0.0.1:8000/register/',
            userDetails,
        {
            headers:{
                //'Authorization':`Token ${token}`,
                'Content-Type' : 'application/json',
                'Accept' : 'application/json'
                
            },
        })
        console.log('user Register::',User)
        return User.data;
    }
)
export const userSlice = createSlice({
    name:'userRegister',
    initialState,
    reducers:{
        Submitdata:(state,action)=>{
            state.data = action.payload;
            state.data = []
        }
    },
    extraReducers :(builder) =>{
       // debugger;
        builder.addCase(fetchUsers.fulfilled,(state,action)=>{
           state.data = action.payload;
            if(action.payload && action.payload && action.payload){
             console.log('Signup successfully!!',action.payload)
            }
           }).addCase(fetchUsers.rejected,(state, action)=>{
            //state.isAuthenticated = false;
            state.data = action.payload;
            console.error("error IS error", state.error)
           });
        }
    })
export const {Submitdata } = userSlice.actions;
export default userSlice.reducer;