import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axios from "axios";
//import React from "react";

const initialState = {
    order :[]
}
export const fetchOrders = createAsyncThunk(
   /* 'fetchOrders',
    async()=>{
    const UserOrders = await axios.get('http://127.0.0.1:8000/order/')
    return UserOrders.data;
}*/
    'POSTDATA',
    async()=>{
        const {UserOrders} = await axios.post('http://127.0.0.1:8000/order/',{
            user:'1',
            product_name:'menswahtch',
            total_product:'1',
        },{
        headers:{
            'Authorization':'Token dc698c58de090c5503185674062de95340fef996',
            'Content-Type' : 'application/json',
            'Accept' : 'application/json'
        }
    }
        )
        return(UserOrders.data);
    }
)
export const OrderSlice = createSlice({
    
    name:'Order',
    initialState,
    reducers:{
       /* showOrder:(state)=>{
            //debugger;
            return state;
        },*/
        PlaceOrder:(state,action)=>{
            //debugger;
            const newOrder = action.payload;
            state.order.push(newOrder);
        },
        ContinueOrder :(state,action) =>{
            const payment = action.payload;
            state.order.push(payment);
        }
    },
    extraReducers:(builder)=>{
        //debugger;
        builder.addCase(fetchOrders.fulfilled,(state,action)=>{
            state.order = action.payload;
        })
    }

})
export const {showOrder,PlaceOrder,ContinueOrder} = OrderSlice.actions;
export default OrderSlice.reducer;
