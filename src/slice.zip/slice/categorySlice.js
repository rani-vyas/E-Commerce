import { createAsyncThunk, createSlice } from "@reduxjs/toolkit"; 
import axios from "axios";
//import React from "react";

const initialState = {
  data : [],
  isAuthenticated : false, 
}
const token = 'dc698c58de090c5503185674062de95340fef996'
export const fetchUserById = createAsyncThunk(
    'fetchId',
    async () =>{
     //debugger;
    const {data} = await axios.get('http://127.0.0.1:8000/category/',{
      headers:{
        'Authorization': `Token ${token}`,
        'Content-Type': 'application/json',
        'Accept' : 'application/json'
      }
    });
    return data.results;
      }
)
export const categorySlice = createSlice({
    name:'category',
    initialState,
    reducers:{
       showCategory(state){
//debugger;
            //state.isAuthenticated = true;
            //return state.data;
            return { ...state, isAuthenticated: true };
        },
    },
    extraReducers : (builder)=>{
        builder.addCase(fetchUserById.fulfilled,(state,action)=>{
          state.isAuthenticated = true;
          state.data=action.payload;
        })
    }
  })
export const {showCategory} = categorySlice.actions
export default categorySlice.reducer;