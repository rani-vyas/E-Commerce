import { createAsyncThunk, createSlice, isPending } from "@reduxjs/toolkit";
import axios from "axios";
//import localStorage from "redux-persist/es/storage";

const results = {
  username:'adminuser',
  email:'adminUser@admin.com',
  password:'admin123@'
}
const initialState ={
    //isAuthenticated : false,
    User: [{}]
}
//const token = localStorage.getItem('dc698c58de090c5503185674062de95340fef996');
export const loginUser = createAsyncThunk(
    'login/Verify credentials',
    async() =>{
        const logindata =  await axios.post('http://127.0.0.1:8000/login/',  
       results,      
    {
       headers:{
           // 'Authorization':`Token${localStorage.getItem(token)}`,
            'Content-Type' : 'application/json',
            'Accept' : 'application/json'
        },
    } 
  
        )
 console.log('logindata:',logindata)
     return logindata.data;   
  }
)

export const loginSlice = createSlice({
    name:'loginusers',
    initialState,
    reducers:{
      loginSuccess: (state, action) => {
            //state.isAuthenticated = true;
            state.User = action.payload;
          },
          logout: (state) => {
            //state.isAuthenticated = false;
            state.User = [{}];
          },
   },
    extraReducers: (builder) => {
      
       builder.addCase(loginUser.pending,()=>{
       // debugger;

        console.log('pending')
       })
       .addCase(loginUser.fulfilled,(state,action)=>{
        //state.isAuthenticated  = true
       // console.log('login Successfully',state.payload.data.key);
        if(action.payload && action.payload && action.payload){
         // debugger;
         console.log('login successfully!!',action.payload)
          //localStorage.setItem('token' , action.payload);
        }
        else{
          console.error("error dispatching",action.payload);
        }
       })
       .addCase(loginUser.rejected,(state, action)=>{
        debugger;
        //state.isAuthenticated = false;
        if(state.User !== state.User){
          console.error('Rejected:(', action.error)
        }
        
       })
      }
    })
    export const{loginSuccess,logouts} = loginSlice.actions;
    export default loginSlice.reducer;
       
